import SumFromString from "../components/SumFromString";

describe('Testing Sum From String Component', () => { 
    test('should return Correct Calculation', () => { 
        expect(SumFromString('12a-b12')).toBe(24)
     })
    test('should return Correct Calculation', () => { 
        expect(SumFromString('1a2b4c')).toBe(7)
     })
    test('should return Correct Calculation', () => { 
        expect(SumFromString('12ab13bc2')).toBe(27)
     })
    test('should return Correct Calculation', () => { 
        expect(SumFromString('abc')).toBe(0)
     })
    test('should return Correct Calculation', () => { 
        expect(SumFromString('abc1.25')).toBe(26)
     })
    test('should return Correct Calculation', () => { 
        expect(SumFromString('11ab-10')).toBe(1)
     })
 })