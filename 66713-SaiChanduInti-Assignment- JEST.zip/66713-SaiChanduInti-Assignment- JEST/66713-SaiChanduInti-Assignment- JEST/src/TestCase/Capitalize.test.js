import Capitalize from "../components/Capitalize";

describe('Test Case for Capitalized String', () => { 
    test('should return string with first letter Capital', () => { 
        expect(Capitalize('normal')).toBe('Normal');
     })
 })