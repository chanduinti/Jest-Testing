import ReverseStr from '../components/ReverseStr';

test('should return string in reverse Order', () => { 
    expect(ReverseStr('Chandu')).toBe('udnahC');
 })