import Calculator from "../components/Calculator";

describe('Testing Calculator', () => { 

    let calc = new Calculator();

    test('should return Addition', () => { 
        expect(calc.Addition(10,20)).toBe(30);
     })
    test('should return Subtraction', () => { 
        expect(calc.Subtract(70,20)).toBe(50);
     })
    test('should return Multiplication', () => { 
        expect(calc.Multiply(10,20)).toBe(200);
     })
    test('should return Devision', () => { 
        expect(calc.Devide(6,4)).toBe(1.5);
     })
 })