import ArrayAnalysis from "../components/ArrayAnalysis";


let Analyze = new ArrayAnalysis();
test('should return following values', () => { 
    
    let inputArray = [2,4,6,10,8]
    expect(Analyze.Analysis(inputArray)).toEqual({
        avg:6,
        min:2,
        max:10,
        length:5
    })
 })