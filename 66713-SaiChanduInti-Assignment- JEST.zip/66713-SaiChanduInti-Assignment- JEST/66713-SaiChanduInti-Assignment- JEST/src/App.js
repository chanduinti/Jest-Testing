import logo from './logo.svg';
import './App.css';
import Capitalize from './components/Capitalize';

function App() {
  return (
    <div className="App">
      <h1>App Component</h1>
    </div>
  );
}

export default App;
