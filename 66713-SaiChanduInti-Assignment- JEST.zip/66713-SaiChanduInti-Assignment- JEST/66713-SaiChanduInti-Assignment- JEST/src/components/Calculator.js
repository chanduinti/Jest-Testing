import React, { Component } from 'react'

export default class Calculator extends Component {

    Addition(a, b) {
        return a+b;
    }

    Subtract(a, b){
        return a-b;
    }

    Multiply(a, b){
        return a*b;
    }

    Devide(a, b){
        return a/b;
    }

}
