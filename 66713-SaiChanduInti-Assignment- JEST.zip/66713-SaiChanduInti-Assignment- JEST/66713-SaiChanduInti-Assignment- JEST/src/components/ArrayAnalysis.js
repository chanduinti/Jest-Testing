import React, { Component } from 'react'

export default class ArrayAnalysis extends Component {
    avgerage = (arr) => {
        let total = 0
        let sum = arr.forEach(element => {
            total = total + element;
        });
        return total/arr.length
    }
  Analysis(arr) {
      return ({
          avg: this.avgerage(arr),
          min: Math.min(...arr),
          max: Math.max(...arr),
          length:arr.length
      })
  }
}
