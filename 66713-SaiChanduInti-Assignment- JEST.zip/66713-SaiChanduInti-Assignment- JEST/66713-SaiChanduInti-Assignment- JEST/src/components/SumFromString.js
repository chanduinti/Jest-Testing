import React from 'react'

export default function SumFromString(str) {
  let count = 0;
  let finalStr='',temp ='+';
  let check = false;

  const isNumber = (ch) => {
      return /^\d$/.test(ch)
  }

  const isCharacter = (ch) => {
      return /^[a-zA-Z]$/.test(ch)
  }

  const isSymbol = (ch) => {
    if(ch == '%' || ch == '/' || ch == '*' || ch == '+' || ch == '-'){
        return true;
      }else{
        return false;
      }
  }
  
  for (let i = 0; i < str.length; i++) {
      if (isNumber(str[i])) {
          if (check) {
              finalStr += temp;
              check = false;
          }
          finalStr += str[i];
          count = 0;
      }else if(isCharacter(str[i])){
          if (count>=1) {
              temp = '+';
              count = 0;
          }
          check = true;
      }else if(isSymbol(str[i])){
          temp = str[i];
          count ++;
      }else{
          check=true;
      }
  }
  
  let result = eval(finalStr);

  console.log(finalStr+" = "+result);
  if (result !== undefined){
      return result;
  }else{
      return 0;
  }
}
