import React from 'react'

function ReverseStr(str) {
    let expoStr = ''

    for (let i = (str.length-1); i >=0 ; i--) {
        expoStr += str[i]
    }

  return expoStr
}

export default ReverseStr